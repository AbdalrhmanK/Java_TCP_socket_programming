import java.io.File;

import java.io.FileNotFoundException;

import java.io.FileWriter;

import java.io.IOException;

import java.io.PrintWriter;

import java.util.Scanner;

public class recycle {

	// Price of each item
	public double plasticPrice = 0.01;
	public double metalPrice = 0.08;
	public double glassPrice = 0.02;
	public double clothPrice = 0.06;
	public double woodPrice = 0.04;
	public double paperPrice = 0.05;
	public double tiresPrice = 0.1;

	// this is a suggestion
	public String sug = "none";
	//

	// Weight of each item
	public double plasticWeight = 0;
	public double metalWeight = 0;
	public double glassWeight = 0;
	public double clothWeight = 0;
	public double woodWeight = 0;
	public double paperWeight = 0;
	public double tiresWeight = 0;

	// Total of Weight
	public double total = 0;

	// Offer number (0,1,2,3)
	public int offerNumber = 0;

	// Total money earned
	public double totalPrice = 0;

	// Return menu

	public String menu() {

		String menu = " Welcome to Recycle app \n Please enter the number of the service: \n 1. Plastic recycling \n 2. Metal recycling \n 3. Glass recycling \n 4. Cloth recycling \n 5. Wood recycling \n 6. Paper recycling \n 7. Recycle car tires \n 8. View all recycled materials \n 9. Offers  \n 10. Give Us a Suggestion  \n 11. Exit ";

		return menu;

	}

	// Calculate plastic price and return the money earned

	public double plasticPriceCalculation(double weight) {

		applyOffer(weight);

		plasticWeight = weight + plasticWeight;

		double pPrice = weight * plasticPrice;

		totalPrice = pPrice + totalPrice;

		total = weight + total;

		plasticPrice = 0.01;

		return pPrice;

	}

	// Calculate metal price and return the money earned

	public double metalPriceCalculation(double weight) {

		applyOffer(weight);

		metalWeight = weight + metalWeight;

		double mPrice = weight * metalPrice;

		totalPrice = mPrice + totalPrice;

		total = weight + total;

		metalPrice = 0.08;

		return mPrice;

	}

	// Calculate glass price and return the money earned

	public double glassPriceCalculation(double weight) {

		applyOffer(weight);

		glassWeight = weight + glassWeight;

		double gPrice = weight * glassPrice;

		totalPrice = gPrice + totalPrice;

		total = weight + total;

		glassPrice = 0.02;

		return gPrice;

	}

	// Calculate cloth price and return the money earned

	public double clothPriceCalculation(double weight) {

		applyOffer(weight);

		clothWeight = weight + clothWeight;

		double cPrice = weight * clothPrice;

		totalPrice = cPrice + totalPrice;

		total = weight + total;

		clothPrice = 0.06;

		return cPrice;

	}

	// Calculate wood price and return the money earned

	public double woodPriceCalculation(double weight) {

		applyOffer(weight);

		woodWeight = weight + woodWeight;

		double wPrice = weight * woodPrice;

		totalPrice = wPrice + totalPrice;

		total = weight + total;

		woodPrice = 0.04;

		return wPrice;

	}

	// Calculate paper price and return the money earned

	public double paperPriceCalculation(double weight) {

		applyOffer(weight);

		paperWeight = weight + paperWeight;

		double pPrice = weight * paperPrice;

		totalPrice = pPrice + totalPrice;

		total = weight + total;

		paperPrice = 0.05;

		return pPrice;

	}

	// Calculate tires price and return the money earned

	public double tiresPriceCalculation(double weight) {

		applyOffer(weight);
		tiresWeight = weight + tiresWeight;
		double tPrice = weight * tiresPrice;
		totalPrice = tPrice + totalPrice;
		total = weight + total;
		tiresPrice = 0.1;

		return tPrice;

	}

	// assign Suggestion in variable , and then return the Suggestion
	public String suggestion(String sug) {
		this.sug = sug;
		return this.sug;
	}

	// This method return recycle object contains all recycled materials from file

	public recycle viewAllRecycledMaterials() {
		recycle rec = new recycle();
		try {
			File myObj = new File("recycledMaterials.txt");
			if (myObj.createNewFile()) {
				System.out.println("File created: " + myObj.getName());
				PrintWriter myWriter = new PrintWriter("recycledMaterials.txt");
				myWriter.println("Recycled Plastic: " + plasticWeight);
				myWriter.println("Recycled Metal: " + metalWeight);
				myWriter.println("Recycled Glass: " + glassWeight);
				myWriter.println("Recycled Cloth: " + clothWeight);
				myWriter.println("Recycled Wood: " + woodWeight);
				myWriter.println("Recycled Paper: " + paperWeight);
				myWriter.println("Recycled Tires: " + tiresWeight);
				myWriter.println("Client Suggestion:" + sug);
				myWriter.println("Total Weight: " + total);
				myWriter.println("Total Money You Got: " + totalPrice);

				// myWriter.println("Offer: "+offers());
				myWriter.close();
				rec.plasticWeight = plasticWeight;
				rec.metalWeight = metalWeight;
				rec.glassWeight = glassWeight;
				rec.clothWeight = clothWeight;
				rec.woodWeight = woodWeight;
				rec.paperWeight = paperWeight;
				rec.tiresWeight = tiresWeight;
				rec.sug = sug;

			} else {
				System.out.println("File already exists.");
				Scanner myReader = new Scanner(myObj);
				String data = myReader.nextLine();
				double plasticWeightTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				double metalWeightTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				double glassWeightTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				double clothWeightTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				double woodWeightTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				double paperWeightTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				double tiresWeightTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				String suggestion = data.substring(data.indexOf(':') + 1 );
				data = myReader.nextLine();
				double newTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				double newTotalPrice = Double.parseDouble(data.substring(data.indexOf(':') + 1));

				myReader.close();
				rec.plasticWeight = plasticWeightTotal;
				rec.metalWeight = metalWeightTotal;
				rec.glassWeight = glassWeightTotal;
				rec.clothWeight = clothWeightTotal;
				rec.woodWeight = woodWeightTotal;
				rec.paperWeight = paperWeightTotal;
				rec.tiresWeight = tiresWeightTotal;
				rec.sug = suggestion;
				rec.total = newTotal;
				rec.totalPrice = newTotalPrice;
			
			}
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
		return rec;
	}

	// This method save all information needed in the file

	public void save() {
		try {
			double allTotal = getTotal();

			PrintWriter myWriter = new PrintWriter("recycledMaterials.txt");
			myWriter.println("Recycled Plastic: " + plasticWeight);
			myWriter.println("Recycled Metal: " + metalWeight);
			myWriter.println("Recycled Glass: " + glassWeight);
			myWriter.println("Recycled Cloth: " + clothWeight);
			myWriter.println("Recycled Wood: " + woodWeight);
			myWriter.println("Recycled Paper: " + paperWeight);
			myWriter.println("Recycled Tires: " + tiresWeight);
			myWriter.println("Client Suggestion:" + sug);
			myWriter.println("Total Weight: " + allTotal);
			myWriter.println("Total Money You Got: " + totalPrice);
			// myWriter.println(offer);
			myWriter.close();
			total = 0;

			System.out.println("Successfully wrote to the file.");
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}

	// This method apply any offer exist to the client

	public void applyOffer(double weight) {

		if (weight < 2000) {

			plasticPrice = 0.01;

			metalPrice = 0.08;

			glassPrice = 0.02;

			clothPrice = 0.06;

			woodPrice = 0.04;

			paperPrice = 0.05;

			tiresPrice = 0.1;

			offerNumber = 0;

		}

		if (weight >= 2000 && weight < 4000) {

			plasticPrice = 0.01 + 0.01;

			metalPrice = 0.08 + 0.01;

			glassPrice = 0.02 + 0.01;

			clothPrice = 0.06 + 0.01;

			woodPrice = 0.04 + 0.01;

			paperPrice = 0.05 + 0.01;

			tiresPrice = 0.1 + 0.01;

			offerNumber = 1;

		} else if (weight >= 4000 && weight < 6000) {

			plasticPrice = 0.01 + 0.02;

			metalPrice = 0.08 + 0.02;

			glassPrice = 0.02 + 0.02;

			clothPrice = 0.06 + 0.02;

			woodPrice = 0.04 + 0.02;

			paperPrice = 0.05 + 0.02;

			tiresPrice = 0.1 + 0.02;

			offerNumber = 2;

		} else if (weight >= 6000) {

			plasticPrice = 0.01 + 0.03;

			metalPrice = 0.08 + 0.03;

			glassPrice = 0.02 + 0.03;

			clothPrice = 0.06 + 0.03;

			woodPrice = 0.04 + 0.03;

			paperPrice = 0.05 + 0.03;

			tiresPrice = 0.1 + 0.03;

			offerNumber = 3;

		}

	}

	// This method return a string explain the offer that applied to the client

	public String offers() {

		String offer = "";

		if (offerNumber == 0) {

			offer = "You don't have an offer.";

		} else if (offerNumber == 1) {

			offer = "You have an offer that the price of the gram increased by 0.01 SR. ";

		} else if (offerNumber == 2) {

			offer = "You have an offer that the price of the gram increased by 0.02 SR. ";

		} else if (offerNumber == 3) {

			offer = "You have an offer that the price of the gram" + " increased by 0.03 SR. ";

		}

		return offer;

	}

	// This method get recycled materials from file plus recycled materials in this
	// class

	public void getRecycledMaterials() {
		try {
			File myObj = new File("recycledMaterials.txt");
			if (myObj.createNewFile()) {
				System.out.println("File created: " + myObj.getName());
				PrintWriter myWriter = new PrintWriter("recycledMaterials.txt");
				myWriter.println("Recycled Plastic: " + plasticWeight);
				myWriter.println("Recycled Metal: " + metalWeight);
				myWriter.println("Recycled Glass: " + glassWeight);
				myWriter.println("Recycled Cloth: " + clothWeight);
				myWriter.println("Recycled Wood: " + woodWeight);
				myWriter.println("Recycled Paper: " + paperWeight);
				myWriter.println("Recycled Tires: " + tiresWeight);
				myWriter.println("Client Suggestion:" + sug);
				myWriter.println("Total Weight: " + total);
				myWriter.println("Total Money You Got: " + totalPrice);
			
				// myWriter.println("Offer: "+offers());
				myWriter.close();
			} else {
				System.out.println("File already exists.");
				Scanner myReader = new Scanner(myObj);
				String data = myReader.nextLine();
				double plasticWeightTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				double metalWeightTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				double glassWeightTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				double clothWeightTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				double woodWeightTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				double paperWeightTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				double tiresWeightTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				String suggestion = data.substring(data.indexOf(':') + 1 );
				data = myReader.nextLine();
				double newTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				data = myReader.nextLine();
				double newTotalPrice = Double.parseDouble(data.substring(data.indexOf(':') + 1));
				myReader.close();
				plasticWeight = plasticWeight + plasticWeightTotal;
				metalWeight = metalWeight + metalWeightTotal;
				glassWeight = glassWeight + glassWeightTotal;
				clothWeight = clothWeight + clothWeightTotal;
				woodWeight = woodWeight + woodWeightTotal;
				paperWeight = paperWeight + paperWeightTotal;
				tiresWeight = tiresWeight + tiresWeightTotal;
				sug = suggestion ; 
				totalPrice = totalPrice + newTotalPrice;
			}
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}

	// Get total from file

	public double getTotal() {

		double allTotal = total;

		try {

			File myObj = new File("recycledMaterials.txt");

			Scanner myReader = new Scanner(myObj);

			int i = 0;

			String data;

			while (i != 8 && myReader.hasNext()) {

				data = myReader.nextLine();

				i++;

			}

			if (i != 0) {

				data = myReader.nextLine();

				allTotal = Double.parseDouble(data.substring(data.indexOf(':') + 1)) + allTotal;

			}

			myReader.close();

		} catch (FileNotFoundException e) {

			System.out.println("An error occurred.");

			e.printStackTrace();

		}

		return allTotal;

	}

	// Return string contains all information needed

	public String print(recycle rec) {

		String print = " Recycled Plastic: " + rec.plasticWeight + "\n Recycled Metal: " + rec.metalWeight
				+ "\n Recycled Glass: " + rec.glassWeight + "\n Recycled Cloth: " + rec.clothWeight
				+ "\n Recycled Wood: " + rec.woodWeight + "\n Recycled Paper: " + rec.paperWeight
				+ "\n Recycled Tires: " + rec.tiresWeight + "\n Client Suggestion:" +rec.sug+ "\n Total Weight: " + rec.total + "\n Total Money You Got: "
				+ rec.totalPrice;

		return print;

	}

	// This method return all offers in this app

	public String printOffers() {

		String offers = "1. Recycle 2000 grams  to increase the amount you get from recycling 0.01 SAR per gram.\n";

		offers = offers + "2. Recycle 4000 grams  to increase the amount you get from recycling 0.02 SAR per gram.\n";

		offers = offers + "3. Recycle 6000 grams  to increase the amount you get from recycling 0.03 SAR per gram.";

		return offers;

	}

}