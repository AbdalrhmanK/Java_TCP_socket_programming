
import java.net.*;

import java.io.*;

public class Server {

	public static recycle rec = new recycle();

	public static double totalPrice = -1;

	public static double dWeight;
	public static String clientSug;
	
	public static void main(String[] args) throws IOException {

		// Open server connection

		ServerSocket socket = new ServerSocket(34);

		System.out.println("Server started");

		System.out.println("Waiting for a client ...");

		// Accept client connection

		Socket socket2 = socket.accept();

		System.out.println("Client accepted");

		// Get recycled materials from file

		rec.getRecycledMaterials();

		// service number

		String number = "0";

		// weight of item

		String weight = "0";

		while (!number.equals("11")) {

			// Create print write object to send information to client

			PrintWriter pr = new PrintWriter(socket2.getOutputStream());

			// Send menu to client

			pr.println(rec.menu());

			pr.flush();

			// Create objects to read from client

			InputStreamReader reader = new InputStreamReader(socket2.getInputStream());

			BufferedReader br = new BufferedReader(reader);

			// Read service number from client

			number = br.readLine();

			// If user entered 11 (Exit) send to him thank you..

			if (number.equals("11")) {

				pr.println("Thank you for using our app :)");

				pr.flush();

				break;

			}

			// If user entered any service number from 1 to 7

			if (number.equals("1") || number.equals("2") || number.equals("3") || number.equals("4")
					|| number.equals("5") || number.equals("6") || number.equals("7")) {

				boolean exception = true;

				// Loop if user did not enter a number (double , int ..)

				while (exception) {

					try {

						pr.println("How much weight do you have in grams? ");

						pr.flush();

						weight = br.readLine();

						dWeight = Double.parseDouble(weight);

						exception = false;

						pr.println("false");

						pr.flush();

					} catch (Exception e) {

						pr.println("true");

						pr.println("wrong entry!! try again.");

						pr.flush();

					}

				}

			}
			// this is for Suggestion
			if (number.equals("10")) {
				boolean exception = true;
				// Loop if user did not enter a number (double , int ..)
				while (exception) {
					try {
						pr.println("Write your Suggestion ,to improve our system ");
						pr.flush();
						weight = br.readLine();
					
						exception = false;
						pr.println("false");
						pr.flush();
					} catch (Exception e) {
						pr.println("true");
						pr.println("wrong entry!! try again.");
						pr.flush();
					}

				}
			}

			// Calculate the price and save it in the file for the service number

			switch (number) {

			case "1":

				totalPrice = rec.plasticPriceCalculation(Double.parseDouble(weight));

				rec.save();

				break;

			case "2":

				totalPrice = rec.metalPriceCalculation(Double.parseDouble(weight));

				rec.save();

				break;

			case "3":

				totalPrice = rec.glassPriceCalculation(Double.parseDouble(weight));

				rec.save();

				break;

			case "4":

				totalPrice = rec.clothPriceCalculation(Double.parseDouble(weight));

				rec.save();

				break;

			case "5":

				totalPrice = rec.woodPriceCalculation(Double.parseDouble(weight));

				rec.save();

				break;

			case "6":

				totalPrice = rec.paperPriceCalculation(Double.parseDouble(weight));

				rec.save();

				break;

			case "7":

				totalPrice = rec.tiresPriceCalculation(Double.parseDouble(weight));

				rec.save();

				break;

			case "8":

				pr.println(rec.print(rec.viewAllRecycledMaterials()));

				pr.flush();

				break;

			case "9":

				pr.println(rec.printOffers());

				pr.flush();

				break;

			case "10":

				pr.println(rec.suggestion(weight));
				rec.save();
				pr.flush();

				break;

			default:

				pr.println("Wrong number!! try again please. ");

				pr.flush();

				System.out.println("Wrong choice");

			}

			// Send to the client the total price

			if (number.equals("1") || number.equals("2") || number.equals("3") || number.equals("4")
					|| number.equals("5") || number.equals("6") || number.equals("7")) {

				String offer = rec.offers();

				pr.println("Well Done !! You will get " + totalPrice + " SR. ");

				pr.println(offer);

				pr.flush();

			}
			if (number.equals("10")) {
				pr.println("Thank you for Suggestion , we hope it improves our System ");
				pr.flush();
				
			}

		}

		// Close server socket

		socket.close();

		// Close the socket of accepted client connection

		socket2.close();

	}

}