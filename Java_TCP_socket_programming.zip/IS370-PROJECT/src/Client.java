import java.net.*;
import java.util.Scanner;
import java.io.*;

public class Client {

	public static void main(String[] args) throws IOException {

		// Open a connection to a server:
		Socket socket = new Socket("localhost", 34);
		// Create objects to read from the server
		InputStreamReader reader = new InputStreamReader(socket.getInputStream());
		BufferedReader br = new BufferedReader(reader);
		// The service number that the user will enter
		String serviceNumber = "0";
		// String that will received from serve
		String str = "";
		// The weight of item that the user will enter

		String weight = "0";

		// Create scanner object

		Scanner myObj = new Scanner(System.in);

		while (!serviceNumber.equals("11")) {

			// Print the menu that came from the server
			for (int i = 0; i < 13; i++) {
				System.out.println(br.readLine());
			}

			// Read service number input from the user

			serviceNumber = myObj.nextLine();

			// Create print write object to send information to server

			PrintWriter pr = new PrintWriter(socket.getOutputStream());

			// Send service number to server

			pr.println(serviceNumber);

			pr.flush();

			// Receive all recycled materials from server

			if (serviceNumber.equals("8")) {

				for (int i = 0; i < 10; i++) {

					System.out.println(br.readLine());

				}

				System.out.println();

			}

			// Exit
			if (serviceNumber.equals("11")) {

				str = br.readLine();

				System.out.println(str);

				break;

			}

			// Receive all offers from server
			if (serviceNumber.equals("9")) {
				for (int i = 0; i < 3; i++) {
					System.out.println(br.readLine());

				}
				System.out.println();

			}
			// If user entered any service number from 1 to 7

			if (serviceNumber.equals("1") || serviceNumber.equals("2") || serviceNumber.equals("3")
					|| serviceNumber.equals("4") || serviceNumber.equals("5") || serviceNumber.equals("6")
					|| serviceNumber.equals("7")) {

				// Read "How much weight do you have in grams? " from server

				str = br.readLine();

				System.out.println(str);

				boolean exception = true;

				// Loop if user did not enter a number (double , int ..)

				while (exception) {

					// Read weight of item from user

					weight = myObj.nextLine();

					// Send the weight to server

					pr.println(weight);

					pr.flush();

					// If the user did not enter a number and an exception appeared. variable
					// exception will be true

					exception = Boolean.parseBoolean(br.readLine());

					if (exception) {

						System.out.println(br.readLine());

						System.out.println(br.readLine());

					}

				}

				str = br.readLine();// Read from server "Well Done !! You will get (totalPrice) SR. "

				System.out.println(str);

				str = br.readLine(); // offer

				System.out.println(str);

				System.out.println();

			}

			if (serviceNumber.equals("10")) {
				str = br.readLine();
				System.out.println(str);
				boolean exception = true;
				// Loop if user did not enter a number (double , int ..)

				while (exception) {
					// Read weight of item from user
					weight = myObj.nextLine();
					// Send the weight to server
					pr.println(weight);
					pr.flush();
					// If the user did not enter a number and an exception appeared. variable
					// exception will be true
					exception = Boolean.parseBoolean(br.readLine());
					if (exception) {
						System.out.println(br.readLine());
						System.out.println(br.readLine());
					}
				}
				str = br.readLine();
				System.out.println("This is your Suggestion ---> " + str);
				str = br.readLine();	

			}

			// If the user did not enter a valid service number

			if (!serviceNumber.equals("1") && !serviceNumber.equals("2") && !serviceNumber.equals("3")
					&& !serviceNumber.equals("4") && !serviceNumber.equals("5") && !serviceNumber.equals("6")
					&& !serviceNumber.equals("7") && !serviceNumber.equals("8") && !serviceNumber.equals("9")
					&& !serviceNumber.equals("10") && !serviceNumber.equals("11")) {

				str = br.readLine();

				System.out.println(str);

				System.out.println();

			}

		}

		// Close the socket

		socket.close();

	}

}
